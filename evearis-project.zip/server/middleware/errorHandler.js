export const errorHandler = (err, req, res, next) => {
  console.error('[NEXUS ERROR]', err.stack);
  res.status(err.status || 500).json({
    message: err.message || 'Internal Server Error',
    stack: process.env.NODE_ENV === 'production' ? null : err.stack
  });
};
